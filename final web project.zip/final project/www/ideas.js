function showTasksList(){

    fetch('/ideas', {credentials: 'include'})
        .then(function(response) {
            return response.json();
        })
        .then(function(res) {
            if(res=='-1') { window.location.href = '/'; }
            else{
                let ideasTypes = ["Superior Rooms", "Veranda Rooms", "Terrace Rooms", "Premium Rooms", "Junior Suites"];
                var showIdeasElement = document.getElementById("list_text_id");
                showIdeasElement.innerText = '';
                var textToShow = '';

                Object.keys(res).forEach(function(taskTypeKey) {
                    textToShow +=ideasTypes[taskTypeKey]+":\n";
                    Object.keys(res[taskTypeKey]).forEach(function(tid_key) {
                        textToShow +="      Room "+tid_key+", date: "+ res[taskTypeKey][tid_key]+"\n";
                    });
                });
                showIdeasElement.innerText = textToShow;
            };
        })
};

function showSpecificTasksList(taskTypeKey){

    fetch('/ideas/' + taskTypeKey, {credentials: 'include'})
        .then(function(response) {
            return response.json();
        })
        .then(function(res) {
            if(res=='-1') { window.location.href = '/'; }
            else{
                let ideasTypes = {superiorRooms: "Superior Rooms", verandaRooms: "Veranda Rooms", terraceRooms: "Terrace Rooms", premiumRooms: "Premium Rooms", juniorSuites: "Junior Suites"};
                var showIdeasElement = document.getElementById("list_text_id");
                showIdeasElement.innerText = '';
                var textToShow = '';
                Object.keys(res).forEach(function(tid_key) {
                    textToShow +="Room "+tid_key+", date: "+ res[tid_key]+"\n";
                });
                showIdeasElement.innerText = textToShow;
            };
        })
};

function addTask() {
    var data = document.getElementById("add_task_id").value;
    // Check which radio button is checked
    for(var i=0; i<5; i++){
        if(document.getElementsByName("taskType")[i].checked == true)
            var taskType = document.getElementsByName("taskType")[i].value;
    }
    fetch('/idea', {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ taskType: taskType, idea: data})
    }).then(function (response) {
        console.log(response);
        return response.json();
    }).then(function(res_json){
        console.log(res_json);
        if(res_json== '-1') { window.location.href = '/'; }
        showTasksList();
        document.getElementById("add_task_id").value = "";
    });
}

function deleteTask(){
    var tid = document.getElementById("delete_task_id").value;
    fetch('/idea/' + tid, {
        method: 'DELETE',
        credentials: 'include'
    }).then(function (response) {
        return response.json();
    }).then(function(res_json){
        if (res_json == '-1') {
            window.location.href = '/';
        }
        else if(res_json == '0')
            showTasksList();
        else
            console.log("Unexpected error happened while attempting to remove an item");
        document.getElementById("delete_task_id").value = "";
    });
    window.scrollTo(0,0);

}

function editTaskByID() {

    var text = document.getElementById("task_name").value;
    var tid = document.getElementById("task_id").value;

    fetch('/idea/' + tid, {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({idea: text})
    }).then(function (response) {
        return response.json();
    }).then(function (res_json) {
        if (res_json == '-1') {
            window.location.href = '/'; }
        else if (res_json == '0')
            showTasksList();
        else
            console.log("Unexpected error happened while attempting to edit an existing item");
        document.getElementById("task_name").value = '';
        document.getElementById("task_id").value = '';
    });
    window.scrollTo(0,0);

}

function logout() {
    fetch('/users/logout', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include'
    })
        .then(res => res.json())
        .then(res => {
            window.location.href = '/';
        })
}

function clearDB(){
    console.log("Attempting to clear database");
    fetch('/clearDatabase', {credentials: 'include'})
        .then(function(response) {
            alert("Database cleared");
        })
}