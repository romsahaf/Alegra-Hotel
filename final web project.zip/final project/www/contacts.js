function showContacts(){

    fetch('/contacts', {credentials: 'include'})
        .then(function(response) {
            return response.json();
        })
        .then(function(res) {
            if(res=='-1') { window.location.href = '/'; }
            else{
                var showContactsElement = document.getElementById("list_text_id");
                showContactsElement.innerText = '';
                var textToShow = '';

                Object.keys(res).forEach(function(contactID) {
                        textToShow +="Reservation "+contactID+":  "+ res[contactID]+"\n";
                    });
                showContactsElement.innerText = textToShow;
            };
        })
};

function addContact() {
    var data = document.getElementById("add_contact_id").value;
    fetch('/contact', {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ contact: data})

    }).then(function (response) {
        console.log(response);
        return response.json();
    }).then(function(res_json){
        console.log(res_json);
        if(res_json== '-1') { window.location.href = '/'; }
        showContacts();

        var top = document.getElementById('all-reservations').offsetTop; //Getting Y of target element
        window.scrollTo(0, top);

        document.getElementById("add_contact_id").value = "";
    });
}

function deleteContact(){
    var contactID = document.getElementById("delete_contact_id").value;
    fetch('/contact/' + contactID, {
        method: 'DELETE',
        credentials: 'include'
    }).then(function (response) {
        return response.json();
    }).then(function(res_json){
        if (res_json == '-1') {
            window.location.href = '/';
        }
        else if(res_json == '0')
            showContacts();
        else
            console.log("Unexpected error happened while attempting to remove an item");
        document.getElementById("delete_contact_id").value = "";
    });
}

function logout() {
    fetch('/users/logout', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include'
    })
        .then(res => res.json())
        .then(res => {
            window.location.href = '/';
        })
}