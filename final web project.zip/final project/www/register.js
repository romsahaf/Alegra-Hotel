function submit(userName, eMail, password, verify) {

    console.log(userName);
    console.log(eMail);
    console.log(password);
    console.log(verify);

    if (eMail==="" || userName==="" || password==="" || verify==="") {
        alert("Please fill in all of fields.");
        return;
    }
    if (verify !== password) {
        alert("the passwords does not match, Try again.");
        return;
    }

    fetch('/users/register', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  user: userName,
                                email: eMail,
                                pass: password })
    })
        .then(res => res.json())
        .then(res => {
            if (res === 0) {
                alert("You've signed up to the system successfully.");
                window.location.href = "/";
            } else if (res === 1) {
                alert("The user name was found in the system, try another user name");
            } else {
                console.log(res);
                alert("an error has occured");
            }
        });
}