function submit(userName, password) {
    if (userName=="" || password=="") {
        alert("Please fill in your credentials");
        return;
    }
    fetch('/users/login', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ user: userName, pass: password })
    })
        .then(res => res.json())
        .then(res => {
            if (res == '0') {
                window.location.href = "/home.html";
            } else if (res == '1') {
                alert("Please sign up before logging in to your user.");
                window.location.href = "/register.html";
            } else {
                console.log(res)
                alert("error has occured");
            }
        });
}