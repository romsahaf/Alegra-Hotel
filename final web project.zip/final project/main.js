let bodyParser = require('body-parser')
let express = require('express');
let fs = require('fs');
let session = require('express-session');
let app = express();
let fetch = require("node-fetch");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/public',express.static('public'));
app.use(express.static('www'));

let cookies = {
    MaximumAge: 60 * 1000 * 30,
    isConnected: function () { return (this.MaximumAge > this.currentAge) },
    isExist: false,
    startDate: undefined,
    currentAge: 0
};

app.use(session({
    secret: 'ex2',
    resave: true,
    saveUninitialized: true,
}));

let NoSessionRequests = ['/', '/users/login', '/users/register', '/login.html', '/register.html']
let assignedUserId = undefined;
let dbFile = "dataBase.json";

let loginPath = __dirname + "/www/login.html";
let registerPath = __dirname + "/www/register.html";
let ideasPath = __dirname + "/www/ideas.html";


function isSessionExist(req) {
    if (cookies.isExist) {
        cookies.currentAge = Date.now() - cookies.startDate;
    }
    if (cookies.isExist && cookies.isConnected() && req.session.views) {
        req.session.views = req.session.views + 1;
        return true;
    } else {
        destroySession();
        return false;
    }
}

function destroySession() {
    cookies.expired = true;
    assignedUserId = undefined;
}

function startSession(req, key) {
    assignedUserId = key;
    cookies.startDate = Date.now();
    cookies.isExist = true;
    req.session.views = 1
    req.session.save();
}

app.use(function (req, res, next) {
    if (NoSessionRequests.indexOf(req.url) > -1 || isSessionExist(req)) {
        return next();
    } else {
        if(req.headers.referer == undefined)
            res.redirect('/');
        else
            res.end('-1');
    }
});

app.get('/', function (req, res) {
    res.sendFile(loginPath);
});

app.get('/ideas.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.post('/users/login', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if (err) { throw err; }
            let dataBase = JSON.parse(data);

            // Verify the password
            Object.keys(dataBase).forEach(function (key) {
                if ( (req.body.pass === dataBase[key]["pass"]) && (req.body.user === dataBase[key]["username"])) {
                    startSession(req, key);
                    res.status(302);
                    res.end('0');
                }
            });

            res.end('1');
        });
    } catch (err) {
        if(isSessionExist(req)) {
            res.end('1');}
        else {
            res.end('-1');
        }
    }
})

app.get('/register.html', function (req, res) {
    res.sendFile(registerPath);
});

app.get('/work.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.get('/about.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.get('/important.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.get('/other.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.post('/ideas.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.get('/family.html', function (req, res) {
    res.sendFile(ideasPath);
});

app.post('/users/logout', function (req, res) {
    destroySession();
    res.end('-1');
})

app.post('/users/register', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if (err) { throw err; }
            let db = JSON.parse(data.toString());

            // Make sure the user name doesn't exist
            Object.keys(db).forEach(function (key) {
                if (db[key]["username"] === req.body.user) {
                    res.end('1');
                }
            });

            // If the user doesn't exist, create a new one
            db["id_" + Object.keys(db).length] =
                {
                    "name": req.body.name,
                    "username": req.body.user,
                    "pass": req.body.pass,
                    "tasksCounter": 0,
                    "superiorRooms": {},
                    "verandaRooms": {},
                    "terraceRooms": {},
                    "premiumRooms": {},
                    "juniorSuites": {},
                    "contacts": {},
                    "contactsCounter": 0
                };

            //Update the dataBase.json file
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if(isSessionExist(req)) {
                        res.end('1');}
                    else {
                        res.end('-1');
                    }
                }
            });

            res.end('0');
        });
    } catch (err) {
        res.end('2');
    }
})

app.get('/fun.html', function (req, res) {
    res.sendFile(ideasPath);
});


// Show all rooms
app.get('/ideas', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let dataBase = JSON.parse(data.toString());
            let resData=[];
            resData[0] = dataBase[assignedUserId]["superiorRooms"];
            resData[1] =  dataBase[assignedUserId]["verandaRooms"];
            resData[2] = dataBase[assignedUserId]["terraceRooms"];
            resData[3] = dataBase[assignedUserId]["premiumRooms"];
            resData[4] = dataBase[assignedUserId]["juniorSuites"];
            return res.json(resData); }
    });
})


// Show all reservations
app.get('/contacts', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data.toString());
            return res.json(db[assignedUserId]["contacts"]); }
    });
})

// Create new room
app.put('/contact', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if (err) throw err;
            let db = JSON.parse(data.toString());
            let contactId =  db[assignedUserId].contactsCounter;
            db[assignedUserId].contactsCounter = db[assignedUserId].contactsCounter+ 1;
            // Update dataBase with a new contact
            db[assignedUserId]['contacts'][contactId] = req.body.contact;

            // Add the new message to the dataBase.json file by updating it
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if (isSessionExist(req)) {
                        res.json('-1'); }
                    else { throw err; }
                }
                res.json(contactId);
            });
        });

    } catch (err) {
        if (isSessionExist(req)) {
            res.json('-1'); }
        else {
            throw err; }
    }

})

// Delete room
app.delete('/contact/:contactID', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if(err) {
                throw err; }
            let db = JSON.parse(data);

            Object.keys(db[assignedUserId]["contacts"]).forEach(function(contactIDkey) {
                if(contactIDkey === req.params.contactID)
                    delete db[assignedUserId]["contacts"][req.params.contactID];
            });

            // update the dataBase.json file
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if (isSessionExist(req)) {
                        res.json('-1'); }
                    else { throw err; }
                }
            });
        });

        res.end('0');
    } catch (err) {
        if(isSessionExist(req)) {
            res.end('1');}
        else {
            res.end('-1');
        }
    }})

// Show superiorRooms
app.get('/ideas/superiorRooms', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data);
            let resData;
            resData = db[assignedUserId]["superiorRooms"];
            return res.json(resData); }
    });
})

// Show premiumRooms
app.get('/ideas/premiumRooms', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data);
            let resData;
            resData = db[assignedUserId]["premiumRooms"];
            return res.json(resData); }
    });
})

// Show verandaRooms
app.get('/ideas/verandaRooms', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data);
            let resData=[];
            resData = db[assignedUserId]["verandaRooms"];
            return res.json(resData); }
    });
})

// Show terraceRooms
app.get('/ideas/terraceRooms', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data);
            let resData;
            resData = db[assignedUserId]["terraceRooms"];
            return res.json(resData); }
    });
})

// Show juniorSuites
app.get('/ideas/juniorSuites', function (req, res) {
    fs.readFile(dbFile, function (err, data) {
        if (err) {
            if (isSessionExist(req)) {
                res.json('-1');
            } else { throw err; } }
        else {
            let db = JSON.parse(data);
            let resData;
            resData = db[assignedUserId]["juniorSuites"];
            return res.json(resData); }
    });
})

// Create new resevration
app.put('/idea', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if (err) throw err;
            let db = JSON.parse(data);
            let taskName = req.body.taskType;
            let taskId =  db[assignedUserId].tasksCounter;
            db[assignedUserId].tasksCounter = db[assignedUserId].tasksCounter + 1;
            // Update dataBase with a new message
            db[assignedUserId][taskName][taskId] = req.body.idea;

            // Add the new message to the dataBase.json file by updating it
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if (isSessionExist(req)) {
                        res.json('-1'); }
                    else { throw err; }
                }
                res.json(taskId);
            });
        });

    } catch (err) {
        if (isSessionExist(req)) {
            res.json('-1'); }
        else {
            throw err; }
    }

})

// Delete resrvation
app.delete('/idea/:id', function (req, res) {
    try {
        fs.readFile(dbFile, function (err, data) {
            if(err) {
                throw err; }
            let db = JSON.parse(data);

            Object.keys(db[assignedUserId]).forEach(function(taskTypeKey) {
                Object.keys(db[assignedUserId][taskTypeKey]).forEach(function(key) {
                    if(key === req.params.id)
                        delete db[assignedUserId][taskTypeKey][req.params.id];
                });
            });

            // update the dataBase.json file
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if (isSessionExist(req)) {
                        res.json('-1'); }
                    else { throw err; }
                }
            });
        });

        res.end('0');
    } catch (err) {
        if(isSessionExist(req)) {
            res.end('1');}
        else {
            res.end('-1');
        }
    }})

// Edit existing reservation
app.post('/idea/:id', function (req, res) {
    let flag=false;
    try {
        fs.readFile(dbFile, function (err, data) {
            if (err) { throw err; }
            let db = JSON.parse(data.toString());
            // Check if the required message exists.

            Object.keys(db[assignedUserId]).forEach(function(taskTypeKey) {
                Object.keys(db[assignedUserId][taskTypeKey]).forEach(function(key) {
                    if(key===req.params.id) {
                        flag=true;
                        db[assignedUserId][taskTypeKey][req.params.id] = req.body.idea;
                        console.log(req.body.idea);
                    }
                });
            });


            if (flag === false) {
                res.end('0');
            }

            // update the dataBase.json file
            fs.writeFile(dbFile, JSON.stringify(db), function (err) {
                if (err) {
                    if(isSessionExist(req)) {
                        res.end('1');}
                    else {
                        res.end('-1');
                    }
                }
            });
        });

        res.end('0');
    } catch (err) {
        if(isSessionExist(req)) {
            res.end('1');}
        else {
            res.end('-1');
        }
    }
})

function uploadDatabase(){

    fetch('http://localhost:8081/data/persist', {credentials: 'include'})
        .then(function(res) {
            return res.json();
        })
        .then(function(res) {
            if(res=='-1') { window.location.href = '/'; }
            else{
                // update the dataBase.json file
                fs.writeFile(dbFile, JSON.stringify(res), function (err) {
                    if (err) {
                        if (isSessionExist(req)) {
                            res.json('-1'); }
                        else { throw err; }
                    }
                });
            };
        })
};

setInterval(saveDatabase, 10000)
function saveDatabase() {
    try {
        console.log("Attempting to save database");
        fs.readFile(dbFile, function (err, data) {
            if (err) { throw err; }
            let dataBase = JSON.parse(data.toString());

            fetch('http://localhost:8081/saveDatabase', {
                method: 'PUT',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({database: dataBase})
            })
        });
        console.log("Successfully persisted database");
    } catch (err) {
        console.log(err);
        res.end('-1');
    }
}

// Clear database
app.get('/clearDatabase', function (req, res) {
    console.log("Attempting to clear database");
    fetch('http://localhost:8081/data/clean', {
        method: 'PUT',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        credentials: 'include',
    });
    console.log("Successfully cleared database");
    return res.sendStatus(200);
});


let server = app.listen(8080, function () {
    let host = server.address().address
    let port = server.address().port
    console.log("Main app listening at http://%s:%s", host, port)
    uploadDatabase()
})